import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EventManagementSystem1 extends JFrame implements ActionListener {
    private JLabel titleLabel, eventLabel, destinationLabel, dateLabel;
    private JComboBox<String> eventComboBox, destinationComboBox;
    private JTextField dateField;
    private JButton submitButton, nextButton;

    public EventManagementSystem1() {
        setTitle("Event Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        // Background Image
        ImageIcon backgroundImg = new ImageIcon("background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImg);
        backgroundLabel.setBounds(0, 0, 400, 300);
        add(backgroundLabel);

        // Title Label
        titleLabel = new JLabel("Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(50, 10, 300, 30);
        backgroundLabel.add(titleLabel);

        // Event Label
        eventLabel = new JLabel("Event:");
        eventLabel.setBounds(50, 50, 80, 20);
        backgroundLabel.add(eventLabel);

        // Event ComboBox
        String[] events = {"Birthday", "Wedding", "Engagement", "Get Together"};
        eventComboBox = new JComboBox<>(events);
        eventComboBox.setBounds(140, 50, 200, 20);
        backgroundLabel.add(eventComboBox);

        // Destination Label
        destinationLabel = new JLabel("Destination:");
        destinationLabel.setBounds(50, 90, 80, 20);
        backgroundLabel.add(destinationLabel);

        // Destination ComboBox
        String[] destinations = {"Sheraton Hotel (200000tk)", "Le Meridian Hotel (150000tk)", "Inter Continental Hotel (300000tk)"};
        destinationComboBox = new JComboBox<>(destinations);
        destinationComboBox.setBounds(140, 90, 200, 20);
        backgroundLabel.add(destinationComboBox);

        // Date Label
        dateLabel = new JLabel("Date:");
        dateLabel.setBounds(50, 130, 80, 20);
        backgroundLabel.add(dateLabel);

        // Date Field
        dateField = new JTextField();
        dateField.setBounds(140, 130, 200, 20);
        backgroundLabel.add(dateField);

        // Submit Button
        submitButton = new JButton("Submit");
        submitButton.setBounds(150, 180, 100, 30);
        backgroundLabel.add(submitButton);
        submitButton.addActionListener(this);

        // Next Button
        nextButton = new JButton("Next");
        nextButton.setBounds(150, 230, 100, 25);
        backgroundLabel.add(nextButton);
        nextButton.setVisible(false); // Initially invisible
        nextButton.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            // Perform submission logic here
            JOptionPane.showMessageDialog(this, "Event details submitted successfully!");
            submitButton.setVisible(false); // Hide the submit button
            nextButton.setVisible(true); // Show the next button
        } else if (e.getSource() == nextButton) {
            // Open the next page
            new EventManagementSystem();
            dispose(); // Close the current page
        }
    }

    public static void main(String[] args) {
        new EventManagementSystem1();
    }
}


