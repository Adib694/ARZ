import javax.swing.*;
import java.awt.*;

public class ThankYouPage extends JFrame {
    private JLabel messageLabel;

    public ThankYouPage() {
        setTitle("Thank You!");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Create components
        messageLabel = new JLabel("Thank You so much for choosing ARZ Event Organizer");
        messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        messageLabel.setVerticalAlignment(SwingConstants.CENTER);

        // Add components to the content pane
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(messageLabel, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        new ThankYouPage();
    }
}
