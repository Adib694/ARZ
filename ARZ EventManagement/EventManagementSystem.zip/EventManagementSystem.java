import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EventManagementSystem extends JFrame implements ActionListener {
    private JLabel titleLabel, paymentMethodLabel, paymentOptionLabel;
    private JComboBox<String> paymentMethodComboBox, paymentOptionComboBox;
    private JButton submitButton, nextButton;

    public EventManagementSystem() {
        setTitle("Event Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        // Background Image
        ImageIcon backgroundImg = new ImageIcon("background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImg);
        backgroundLabel.setBounds(0, 0, 400, 300);
        add(backgroundLabel);

        // Title Label
        titleLabel = new JLabel("Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(50, 30, 300, 30);
        backgroundLabel.add(titleLabel);

        // Payment Method Label
        paymentMethodLabel = new JLabel("Payment Method:");
        paymentMethodLabel.setBounds(50, 80, 120, 20);
        backgroundLabel.add(paymentMethodLabel);

        // Payment Method ComboBox
        String[] paymentMethods = {"Mobile Banking", "Payment with Card"};
        paymentMethodComboBox = new JComboBox<>(paymentMethods);
        paymentMethodComboBox.setBounds(180, 80, 160, 20);
        backgroundLabel.add(paymentMethodComboBox);
        paymentMethodComboBox.addActionListener(this);

        // Payment Option Label
        paymentOptionLabel = new JLabel("Payment Option:");
        paymentOptionLabel.setBounds(50, 120, 120, 20);
        backgroundLabel.add(paymentOptionLabel);

        // Payment Option ComboBox
        paymentOptionComboBox = new JComboBox<>();
        paymentOptionComboBox.setBounds(180, 120, 160, 20);
        backgroundLabel.add(paymentOptionComboBox);

        // Submit Button
        submitButton = new JButton("Submit");
        submitButton.setBounds(160, 160, 80, 30);
        backgroundLabel.add(submitButton);
        submitButton.addActionListener(this);

        // Next Button
        nextButton = new JButton("Next");
        nextButton.setBounds(150, 210, 100, 25);
        backgroundLabel.add(nextButton);
        nextButton.setVisible(false); // Initially invisible
        nextButton.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            // Perform submission logic here
            JOptionPane.showMessageDialog(this, "Payment processed successfully!");
            submitButton.setVisible(false); // Hide the submit button
            nextButton.setVisible(true); // Show the next button
        } else if (e.getSource() == nextButton) {
            // Open the next page
            new ThankYouPage();
            dispose(); // Close the current page
        } else if (e.getSource() == paymentMethodComboBox) {
            // Update payment options based on the selected payment method
            updatePaymentOptions();
        }
    }

    private void updatePaymentOptions() {
        // Get the selected payment method
        String selectedPaymentMethod = (String) paymentMethodComboBox.getSelectedItem();

        // Clear previous options
        paymentOptionComboBox.removeAllItems();

        // Add new options based on the selected payment method
        if (selectedPaymentMethod.equals("Mobile Banking")) {
            String[] mobileOptions = {"Nagad", "Bkash"};
            for (String option : mobileOptions) {
                paymentOptionComboBox.addItem(option);
            }
        } else if (selectedPaymentMethod.equals("Payment with Card")) {
            String[] cardOptions = {"Visa Card", "Master Card"};
            for (String option : cardOptions) {
                paymentOptionComboBox.addItem(option);
            }
        }
    }

    public static void main(String[] args) {
        new EventManagementSystem();
    }
}


