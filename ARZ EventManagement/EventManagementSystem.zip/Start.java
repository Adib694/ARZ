import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Start {

    public static void main(String[] args) {

        WelcomePage frame = new WelcomePage();
        frame.setVisible(true);
    }
}


