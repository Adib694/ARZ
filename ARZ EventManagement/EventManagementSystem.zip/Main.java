public class Main {
    public static void main(String[] args) {
        // Start with the welcome page
        WelcomePage welcomePage = new WelcomePage();
        
        // Next, create instances of other frames
        EventManagementSystemLogin loginPage = new EventManagementSystemLogin();
        EventManagementSystem1 eventPage = new EventManagementSystem1();
        EventManagementSystem paymentPage = new EventManagementSystem();
        ThankYouPage thankYouPage = new ThankYouPage();

        // Handle transitions from one frame to another
        welcomePage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // When "Next" button is clicked, close welcomePage and open loginPage
                welcomePage.dispose();
                loginPage.setVisible(true);
            }
        });

        loginPage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // After successful login, close loginPage and open eventPage
                loginPage.dispose();
                eventPage.setVisible(true);
            }
        });

        eventPage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // After submitting event details, close eventPage and open paymentPage
                eventPage.dispose();
                paymentPage.setVisible(true);
            }
        });

        paymentPage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // After payment, close paymentPage and open thankYouPage
                paymentPage.dispose();
                thankYouPage.setVisible(true);
            }
        });
    }
}

