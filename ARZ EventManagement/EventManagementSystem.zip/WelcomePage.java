import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WelcomePage extends JFrame implements ActionListener {
    private JButton nextButton;

    public WelcomePage() {
        setTitle("Welcome");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Background Image
        ImageIcon backgroundImg = new ImageIcon("background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImg);
        backgroundLabel.setBounds(0, 0, 400, 300);
        add(backgroundLabel);

        // Next Button
        nextButton = new JButton("Next");
        nextButton.setBounds(150, 230, 100, 25);
        backgroundLabel.add(nextButton);
        nextButton.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nextButton) {
            // Open the login page or any other action you want to perform
            new EventManagementSystemLogin();
            dispose(); // Close the welcome page
        }
    }

    public static void main(String[] args) {
        new WelcomePage();
    }
}
